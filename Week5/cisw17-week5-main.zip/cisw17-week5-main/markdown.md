![](mywebsite-header.png)

# Markdown

Markdown is a simple, plain-text system to write HTML.

## This is a Heading 2

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

### Heading 3

This is a list of my favorite desserts:

* chocolate chip cookies
* vanilla ice cream
* cheesecake

Here is a recipe for taking great notes:

1. Get out your notebook
2. Write down the class and the date
3. Start taking notes

[Markdown was invented by John Gruber at Daring Fireball](https://daringfireball.net/projects/markdown/syntax).

```
<p>this is a code block</p>
```

